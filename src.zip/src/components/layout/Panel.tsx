import React, {useState, useEffect}from 'react';
import WeaknessChart from './WeaknessChart'
interface Props{
  weakness: {}
  selectedTypes: string[]
}

export const Panel: React.FC<Props> = ({weakness, selectedTypes}) => {
  return ( 
      <div className="col-3 card" style={{ }}>
        <div className="row">Row1</div>
        <div className="row">Row2</div>
        <div className="row">
          <WeaknessChart weakness = {weakness} selectedTypes = {selectedTypes}></WeaknessChart>
        </div>
      </div>)
}

export default Panel;