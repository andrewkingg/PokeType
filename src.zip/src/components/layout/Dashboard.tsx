import React from 'react';
import PokemonList from '../pokemon/PokemonList'

interface Props {
  typeHandler: (pokemonType: string[])=>void,
}

export const Dashboard: React.FC<Props>= ({typeHandler}) => {
  return (
    <div className='row'>
      <div className='col'>
        <PokemonList typeHandler ={typeHandler}/>
      </div>
    </div>)
}

export default PokemonList;