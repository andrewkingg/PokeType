import React, {useState, useEffect}from 'react';
import PokemonCard from './PokemonCard'
type Pokemon = {
  name: string,
  url: string
}
interface Props{
  typeHandler: (pokemonType: string[])=>void,
}
export const PokemonList: React.FC<Props> = ({typeHandler}) => {
  const url = "https://pokeapi.co/api/v2/pokemon?limit=30";
  const array: Pokemon[] = [];
  const [pokemon, updatePokemon] = React.useState(array);
  
  useEffect(() => {
    async function getPokemon() {
     await fetch(url)
    .then(result => result.json())
    .then(result => {updatePokemon(result.results)})
    }

    getPokemon();
  },[]);

  return (
    <div className = "row">
      {pokemon.map(pokemon => <PokemonCard
      key = {pokemon.name}
      url = {pokemon.url}
      name = {pokemon.name}
      typeHandler = {typeHandler}
      />)}
    </div>)
}

export default PokemonList;